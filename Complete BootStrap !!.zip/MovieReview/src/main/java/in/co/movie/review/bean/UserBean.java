package in.co.movie.review.bean;

public class UserBean {

}
