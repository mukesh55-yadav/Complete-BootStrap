package in.co.movie.review.Controller;

public interface MRView {
	
	public String APP_CONTEXT = "/MovieReview";
	public String PAGE_FOLDER = "/jsp";
	
	
	//Controller------------------------------
	public String WELCOME_CTL = APP_CONTEXT + "/welcome";
	public String LOGIN_CTL = APP_CONTEXT + "/login";
	public String USER_REGISTRATION_CTL = APP_CONTEXT +  "/register";
	public String FORGET_PASSWORD_CTL = APP_CONTEXT + "/forgetpassword";
	public String USER_LIST_CTL = APP_CONTEXT +  "/userlist";
	public String ABOUT_CTL = APP_CONTEXT + "/about";
	public String CONTACT_CTL = APP_CONTEXT + "/contact";


	//View-------------------------------------
	public String WELCOME_VIEW = PAGE_FOLDER + "/Welcome.jsp";
	public String LOGIN_VIEW = PAGE_FOLDER + "/LoginView.jsp";
	public String USER_REGISTRATION_VIEW = PAGE_FOLDER + "/RegistrationView.jsp";
	public String FORGET_PASSWORD_VIEW = PAGE_FOLDER + "/ForgetPasswordView.jsp";
	public String USER_LIST_VIEW = PAGE_FOLDER + "/UserListView.jsp";
	public String ABOUT_VIEW = PAGE_FOLDER + "/About.jsp";
	public String CONTACT_VIEW = PAGE_FOLDER + "/Contact.jsp";

}
